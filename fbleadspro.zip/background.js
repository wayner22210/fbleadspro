// Wayne – background.js stub (optional, keeps manifest valid)
chrome.runtime.onInstalled.addListener(() => {
  console.log("FBLeadsPro installed.");
});
