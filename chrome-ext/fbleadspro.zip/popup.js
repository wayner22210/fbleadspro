document.getElementById("open-dashboard").onclick = () => {
  chrome.tabs.create({ url: "https://fbleadspro.vercel.app" });
};
