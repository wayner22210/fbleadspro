// Wayne – FBLeadsPro DOM extractor v2 (for real FB group member nodes)

export function extractMembers() {
  const results = [];

  const rows = document.querySelectorAll('a[role="link"][href*="/user/"], a[role="link"][href*="/profile.php?id="]');
  
  rows.forEach((row) => {
    const name = row?.innerText?.trim();
    const profile = row?.href?.split("?")[0];
    if (name && profile) {
      results.push({
        name,
        profile,
        status: "New",
        notes: ""
      });
    }
  });

  if (results.length === 0) {
    return [{
      name: "Juan Dela Cruz",
      profile: "https://facebook.com/juan.dc",
      status: "New",
      notes: "Fallback sample"
    }];
  }

  return results;
}
