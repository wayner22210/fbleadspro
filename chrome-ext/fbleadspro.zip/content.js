// Wayne – content.js v5: Safe injection for Manifest v3

console.log("[FBLeadsPro] Content script active");

function addButtons() {
  if (document.getElementById("fbleadspro-extract-btn")) return;

  // Extract Button
  const extractBtn = document.createElement("button");
  extractBtn.id = "fbleadspro-extract-btn";
  extractBtn.innerText = "Extract Members";
  extractBtn.style.cssText =
    "position:fixed;top:80px;right:20px;z-index:9999;padding:8px 12px;background:#4267B2;color:#fff;border:none;border-radius:4px;cursor:pointer;";

  extractBtn.onclick = () => {
    const script = document.createElement("script");
    script.src = chrome.runtime.getURL("utils/extract.js");
    script.onload = () => {
      if (typeof window.extractMembers === "function") {
        const data = window.extractMembers();
        localStorage.setItem("fbleadspro-data", JSON.stringify(data));
        alert(`✅ Extracted ${data.length} members`);
      } else {
        alert("❌ extractMembers() not available");
      }
    };
    document.body.appendChild(script);
  };

  // Sync Button
  const syncBtn = document.createElement("button");
  syncBtn.innerText = "Sync to Dashboard";
  syncBtn.style.cssText =
    "position:fixed;top:120px;right:20px;z-index:9999;padding:8px 12px;background:#28a745;color:#fff;border:none;border-radius:4px;cursor:pointer;";

  syncBtn.onclick = () => {
    if (typeof window.syncToDashboard === "function") {
      window.syncToDashboard();
    } else {
      alert("❌ Sync function not ready.");
    }
  };

  // Load sync.js before enabling sync
  const syncScript = document.createElement("script");
  syncScript.src = chrome.runtime.getURL("sync.js");
  document.body.appendChild(syncScript);

  // Add both buttons to DOM
  document.body.appendChild(extractBtn);
  document.body.appendChild(syncBtn);
}

window.addEventListener("load", () => {
  if (window.location.href.includes("/groups/")) {
    addButtons();
  }
});
