// Wayne – Sync contacts to dashboard backend

async function syncToDashboard() {
  const contacts = JSON.parse(localStorage.getItem("fbleadspro-data") || "[]");
  if (!contacts.length) {
    alert("❌ No contacts to sync.");
    return;
  }

  const res = await fetch("http://localhost:3000/api/contacts", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(contacts)
  });

  if (res.ok) {
    alert("✅ Synced contacts to dashboard.");
  } else {
    alert("❌ Sync failed.");
  }
}

window.syncToDashboard = syncToDashboard;
