// Wayne – FBLeadsPro background service worker v1
// Required by manifest.json for MV3

chrome.runtime.onInstalled.addListener(() => {
  console.log("[FBLeadsPro] Extension installed");
});
